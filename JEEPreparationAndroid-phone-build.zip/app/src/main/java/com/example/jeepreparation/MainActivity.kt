package com.example.jeepreparation

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper

class MainActivity : Activity() {
    private val PICK_PDF = 41
    private var pdfText = ""
    private var questions = mutableListOf<String>()
    private var index = 0
    private val answers = mutableMapOf<Int, MutableSet<String>>()
    private val marked = mutableSetOf<Int>()
    private var difficulty = "Medium"
    private var secondsPerQuestion = 90
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var questionText: TextView
    private lateinit var optionsBox: LinearLayout
    private lateinit var timerChoice: Spinner
    private var startedAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        showHome()
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label; isAllCaps = false
        setOnClickListener { action() }
    }
    private fun text(value: String, size: Float = 16f): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(Color.rgb(25,35,55)); setPadding(dp(8),dp(8),dp(8),dp(8))
    }
    private fun setup(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18),dp(18),dp(18),dp(18))
            setBackgroundColor(Color.rgb(246,248,252))
        }
        val heading = text(title, 25f).apply { setTypeface(null, Typeface.BOLD) }
        root.addView(heading)
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }
    private fun showHome() {
        setup("JEE Preparation")
        root.addView(text("PDF-based practice • 25 questions per set"))
        root.addView(text("Upload a question paper or study PDF. The app extracts selectable text and separates numbered questions where possible. Please review parsed questions before starting."))
        root.addView(button("Choose PDF from phone") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"
            }
            startActivityForResult(i, PICK_PDF)
        })
        root.addView(text("Difficulty / time per question"))
        val spinner = Spinner(this)
        val choices = arrayOf("Easy — 120 sec/question", "Medium — 90 sec/question", "Hard — 60 sec/question")
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, choices)
        spinner.setSelection(1)
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                difficulty = arrayOf("Easy","Medium","Hard")[position]
                secondsPerQuestion = intArrayOf(120,90,60)[position]
            }
        }
        root.addView(spinner)
        root.addView(text("Question mode: keep the original extracted question text. PDF answer keys are retained in the extracted source text, but automatic matching is not guaranteed."))
        if (pdfText.isNotBlank()) {
            root.addView(text("Loaded PDF: ${questions.size} question candidates detected"))
            root.addView(button("Review extracted questions") { showReview() })
            root.addView(button("Start 25-question quiz") { startQuiz() })
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_PDF && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            try {
                contentResolver.openInputStream(uri).use { input ->
                    val doc = PDDocument.load(input)
                    pdfText = PDFTextStripper().getText(doc)
                    doc.close()
                }
                questions = splitQuestions(pdfText)
                showHome()
            } catch (e: Exception) {
                Toast.makeText(this, "Could not read this PDF. It may be scanned or protected.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun splitQuestions(source: String): MutableList<String> {
        // Heuristic only: splits on numbered question starts. Always review before use.
        val normalized = source.replace("\r", "\n")
        val regex = Regex("(?m)^\\s*(?:Q(?:uestion)?\\s*)?(\\d{1,3})[.)]\\s+")
        val matches = regex.findAll(normalized).toList()
        val out = mutableListOf<String>()
        for (i in matches.indices) {
            val start = matches[i].range.first
            val end = if (i + 1 < matches.size) matches[i+1].range.first else normalized.length
            val part = normalized.substring(start, end).trim()
            if (part.length > 12) out.add(part)
        }
        return out
    }

    private fun showReview() {
        setup("Review PDF questions")
        root.addView(text("Detected ${questions.size} question candidates. Parsing is heuristic; check numbering, diagrams, options, and solutions against your PDF."))
        questions.take(25).forEachIndexed { i, q ->
            root.addView(text("${i+1}. ${q.take(500)}${if(q.length>500) "…" else ""}", 14f))
        }
        root.addView(button("Back") { showHome() })
        root.addView(button("Start quiz") { startQuiz() })
    }

    private fun startQuiz() {
        if (questions.isEmpty()) {
            Toast.makeText(this, "No numbered questions detected. Try a text-based PDF.", Toast.LENGTH_LONG).show()
            return
        }
        index = 0; answers.clear(); marked.clear(); startedAt = System.currentTimeMillis()
        showQuestion()
    }

    private fun showQuestion() {
        setup("Practice test")
        val count = minOf(25, questions.size)
        status = text("Question ${index+1} of $count • $difficulty • ${secondsPerQuestion}s/question")
        root.addView(status)
        questionText = text(questions[index], 17f)
        root.addView(questionText)
        root.addView(text("Select one or more options if applicable. Options are inferred from the extracted text; this starter build does not yet reliably parse answer choices or the PDF answer key."))
        optionsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(optionsBox)
        listOf("A","B","C","D").forEach { opt ->
            val cb = CheckBox(this).apply {
                text = "Option $opt (select only if shown in the source question)"
                isChecked = answers[index]?.contains(opt) == true
                setOnCheckedChangeListener { _, checked ->
                    val set = answers.getOrPut(index) { mutableSetOf() }
                    if (checked) set.add(opt) else set.remove(opt)
                }
            }
            optionsBox.addView(cb)
        }
        root.addView(button("Mark as skipped / unanswered") { marked.add(index); moveNext() })
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        nav.addView(button("Previous") { if(index>0){index--;showQuestion()} })
        nav.addView(button("Next") { moveNext() })
        root.addView(nav)
        root.addView(button("Finish test") { showResult() })
        root.addView(button("Question palette") { showPalette() })
    }

    private fun moveNext() {
        if (index < minOf(25, questions.size)-1) { index++; showQuestion() } else showResult()
    }
    private fun showPalette() {
        setup("Question navigation")
        for (i in 0 until minOf(25, questions.size)) {
            root.addView(button("Question ${i+1}${if(answers[i]?.isNotEmpty()==true) " • answered" else if(i in marked) " • skipped" else ""}") {
                index=i; showQuestion()
            })
        }
        root.addView(button("Back to current question") { showQuestion() })
    }
    private fun showResult() {
        setup("Test summary")
        val count = minOf(25, questions.size)
        val skipped = (0 until count).filter { answers[it].isNullOrEmpty() }
        root.addView(text("Questions attempted: ${count-skipped.size} / $count"))
        root.addView(text("Skipped question numbers: ${skipped.map{it+1}.joinToString().ifEmpty{"None"}}"))
        root.addView(text("Wrong question numbers: Not calculated because a verified answer key has not been parsed from the PDF."))
        root.addView(text("Score: Not calculated without a verified answer key."))
        root.addView(text("Elapsed time: ${(System.currentTimeMillis()-startedAt)/1000} seconds"))
        root.addView(button("Return home") { showHome() })
    }
}
