plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.jeepreparation"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.jeepreparation"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
dependencies {
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
}
