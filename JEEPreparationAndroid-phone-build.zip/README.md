# JEE Preparation Android (starter project)

## Included
- Android PDF picker using the system document picker
- Text extraction from text-based PDFs with PDFBox-Android
- Heuristic splitting of numbered questions and review screen
- 25-question practice flow (or fewer if the PDF has fewer detected questions)
- Easy/Medium/Hard per-question time settings
- Previous/Next navigation and question palette
- Multi-select answer controls
- Final unanswered/skipped question list

## Important limitations
This is a starter implementation, not a complete production JEE test engine:
- It does not OCR scanned/image-only PDFs.
- Question splitting is heuristic; inspect the extracted questions.
- It does not reliably identify the PDF answer key/solutions or auto-grade questions yet. As a result, it deliberately does not invent scores or wrong-answer numbers.
- The per-question time value is currently displayed as a setting; a countdown/auto-submit timer still needs implementation.
- Choice parsing is not complete; the current answer controls are placeholders.

## Build an APK
Open this folder in Android Studio (JDK 17 recommended), allow Gradle sync, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The debug APK is typically generated at `app/build/outputs/apk/debug/app-debug.apk`.

Command line from this folder:
`gradle assembleDebug`

You need Android SDK Platform 35 and a compatible Android Gradle Plugin/Gradle installation. No compiled APK is included unless an actual build succeeds in an Android SDK environment.

## Build the APK using only your phone (cloud build)

1. Download and extract this ZIP on your phone, or upload the ZIP contents to a new GitHub repository using github.com in your browser.
2. In the GitHub repository, open **Actions** and allow workflows if prompted.
3. Select **Build JEE Preparation APK** and tap **Run workflow** (or wait for the first push workflow to run).
4. Open the completed run and download the artifact named **JEE-Preparation-debug-APK**.
5. Extract the downloaded artifact ZIP to get `app-debug.apk`, then tap it to install. Android may ask you to allow installs from your browser or file manager.

This uses GitHub's cloud runners, so no computer or Android IDE is required. A GitHub account is needed. The build has not been verified in this environment; if the workflow fails, open its log to see the build error.
